 <!---Footer section starts--->
 <div class="footer">
           <div class="wrapper">
            <p class="text-center"> All rights reserved, developed by Sreeja and Bhagavathi </p>

            </div>
        </div>
 <!---Footer section ends--->